plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.z77xt.studio"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.z77xt.studio"
        minSdk = 26
        targetSdk = 28
        versionCode = 1
        versionName = "0.1.0"
    }
}
