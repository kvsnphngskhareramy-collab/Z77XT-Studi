package com.z77xt.studio

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.*
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private val bg = Color.rgb(23, 21, 29)
    private val panel = Color.rgb(43, 40, 53)
    private val accent = Color.rgb(183, 139, 255)
    private val prefs by lazy { getSharedPreferences("studio_settings", Context.MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome(false)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int = 16): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun base(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(12))
            setBackgroundColor(bg)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val label = TextView(this).apply {
            text = title; textSize = 21f; setTextColor(Color.WHITE); typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        header.addView(label, LinearLayout.LayoutParams(0, dp(48), 1f))
        val home = button("หน้าหลัก") { showHome(true) }
        header.addView(home)
        root.addView(header)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun text(value: String, size: Float = 15f): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(Color.WHITE); setPadding(0, dp(8), 0, dp(8))
    }

    private fun button(value: String, action: () -> Unit): Button = Button(this).apply {
        text = value; isAllCaps = false; textSize = 14f; setTextColor(Color.WHITE)
        background = rounded(panel, 14); setPadding(dp(10), dp(6), dp(10), dp(6))
        setOnClickListener { action() }
    }

    private fun addButton(value: String, action: () -> Unit) {
        val b = button(value, action)
        val lp = LinearLayout.LayoutParams(-1, dp(52))
        lp.bottomMargin = dp(9)
        content.addView(b, lp)
    }

    private fun showHome(animate: Boolean) {
        base("Z77XT Studio")
        content.addView(text("ตัดต่อและแต่งภาพ • ใช้งานออฟไลน์", 14f))
        addButton("＋  โปรเจกต์ใหม่") { showEditor(true) }
        addButton("⚙  ตั้งค่าแอนิเมชันและแอป") { showSettings(true) }
        content.addView(text("เวอร์ชันต้นแบบ 0.1.0", 12f).apply { setTextColor(0xFFBDB6C9.toInt()) })
        if (animate) animateIn(content)
    }

    private fun showEditor(animate: Boolean) {
        base("โปรเจกต์ใหม่")
        content.addView(text("ตัวอย่างพื้นที่แสดงวิดีโอ", 14f))
        val preview = FrameLayout(this).apply {
            background = rounded(Color.rgb(9, 9, 12), 12)
            addView(TextView(this@MainActivity).apply {
                text = "▶\\n\\nพื้นที่ตัวอย่าง 16:9"; gravity = Gravity.CENTER
                setTextColor(Color.WHITE); textSize = 18f
            }, FrameLayout.LayoutParams(-1, dp(190)))
        }
        content.addView(preview, LinearLayout.LayoutParams(-1, dp(190)))
        content.addView(text("เครื่องมือ", 18f))
        listOf("ตัด / แบ่งคลิป", "เสียง", "ข้อความและคำบรรยาย", "ปรับสี", "เบลอ", "ครอปและหมุน", "อัตราส่วนภาพ").forEach { name ->
            addButton(name) {
                Toast.makeText(this, "เมนู $name จะเพิ่มการทำงานในรุ่นถัดไป", Toast.LENGTH_SHORT).show()
            }
        }
        content.addView(text("อัตราส่วนภาพ", 16f))
        val ratios = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("16:9", "9:16", "1:1", "4:5").forEach { r ->
            val b = button(r) { Toast.makeText(this, "เลือก $r", Toast.LENGTH_SHORT).show() }
            ratios.addView(b, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(4) })
        }
        content.addView(ratios)
        if (animate) animateIn(content)
    }

    private fun showSettings(animate: Boolean) {
        base("ตั้งค่าแอป")
        content.addView(text("แอนิเมชันเมนู", 18f))
        val direction = spinner(listOf("ขึ้น", "ลง", "ซ้าย", "ขวา"), "direction")
        val style = spinner(listOf("เลื่อน", "จาง", "ขยาย", "ผสม", "ไม่มี"), "style")
        val speed = spinner(listOf("เร็ว", "ปกติ", "ช้า"), "speed")
        content.addView(text("ทิศทางการเปิดเมนู"))
        content.addView(direction)
        content.addView(text("รูปแบบแอนิเมชัน"))
        content.addView(style)
        content.addView(text("ความเร็ว"))
        content.addView(speed)
        addButton("ทดลองแอนิเมชัน") { animateIn(content) }
        addButton("คืนค่าเริ่มต้น") {
            prefs.edit().clear().apply()
            showSettings(true)
        }
        content.addView(text("การตั้งค่าจะบันทึกในเครื่องโดยอัตโนมัติ", 12f))
        if (animate) animateIn(content)
    }

    private fun spinner(options: List<String>, key: String): Spinner {
        val s = Spinner(this)
        s.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options)
        val saved = prefs.getString(key, when (key) { "direction" -> "ขึ้น"; "style" -> "เลื่อน"; else -> "ปกติ" })
        s.setSelection(options.indexOf(saved).coerceAtLeast(0))
        s.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                prefs.edit().putString(key, options[position]).apply()
            }
        }
        return s
    }

    private fun animateIn(view: View) {
        val style = prefs.getString("style", "เลื่อน")
        val direction = prefs.getString("direction", "ขึ้น")
        val speed = prefs.getString("speed", "ปกติ")
        if (style == "ไม่มี") return
        val duration = when (speed) { "เร็ว" -> 140L; "ช้า" -> 420L; else -> 250L }
        view.alpha = if (style == "จาง" || style == "ผสม") 0f else 1f
        view.scaleX = if (style == "ขยาย") 0.94f else 1f
        view.scaleY = if (style == "ขยาย") 0.94f else 1f
        val offset = dp(24).toFloat()
        view.translationX = if (style == "เลื่อน" || style == "ผสม") when (direction) { "ซ้าย" -> offset; "ขวา" -> -offset; else -> 0f } else 0f
        view.translationY = if (style == "เลื่อน" || style == "ผสม") when (direction) { "ขึ้น" -> offset; "ลง" -> -offset; else -> 0f } else 0f
        view.animate().alpha(1f).translationX(0f).translationY(0f).scaleX(1f).scaleY(1f)
            .setDuration(duration).setInterpolator(AccelerateDecelerateInterpolator()).start()
    }
}
